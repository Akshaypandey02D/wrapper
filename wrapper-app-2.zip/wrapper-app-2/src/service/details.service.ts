import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private apiUrl = 'https://useapp55824.mhf.mhc/api/v2/workflow_job_templates/28/launch'; // Base API URL
  private authToken = '47VMoCUfyXtLZHGA3FBKVrQTOOFQXZ'; 

  constructor(private http: HttpClient) {}

  /**
   * Sends a POST request with the specified payload to the API, including the auth token in the headers.
   * @returns An Observable of the response.
   */
  public postAppDetails(): Observable<any> {
    const payload = {
     
      extra_vars: {
        appname: 'name',
        appversion: 'version',
        appvendor: 'publisher',
        authname: 'Gaurav',
        description: 'This is demo setup',
        email_id: 'gaurav.dhyani2@spglobal.com',
        disp_name: "epasetup.msi"
      },
    };

 
    const headers = new HttpHeaders({
      Authorization: `Bearer ${this.authToken}`, 
      'Content-Type': 'application/json', 
    });

    return this.http.post(this.apiUrl, payload, { headers }).pipe(
      catchError((error) => {
        console.error('Error occurred:', error);
        return throwError(() => error);
      })
    );
  }
}
