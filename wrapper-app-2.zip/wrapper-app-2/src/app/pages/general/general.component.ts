import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeploymentSectionComponent } from "./deployment-section/deployment-section.component";
import { PackageDetectionSectionComponent } from "./package-detection-section/package-detection-section.component";
import { AdditionalInfoSectionComponent } from "./additional-info-section/additional-info-section.component";
import { FormBuilder, FormGroup,ReactiveFormsModule } from '@angular/forms';
import { ApiService } from '../../../service/details.service';

interface Field {
  label: string;
  key: string;
  value: string;
}

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss'],
  imports: [DeploymentSectionComponent, PackageDetectionSectionComponent, AdditionalInfoSectionComponent,ReactiveFormsModule,CommonModule],
  providers:[ApiService]
})
export class GeneralComponent {
  // Dummy dynamic data for the form
  public  applicationInfo = {
    name: '-',
    version: '-',
    publisher: '-',
    architecture: 'x86',
    language: 'EN',
    author: 'bharat.singh',
    description: '-'
  };

  public deploymentConfig = {
    suppressReboot: true,
    terminalServerMode: false,
    installationMode: 'Interactive'
  };

  public packageDetectionType = 'Registry';

  public notes: string = 'this is demo';

  informationUrl: string = '';

  constructor(private fb: FormBuilder,private apiService:ApiService ) {
    // Initialize the form with properly typed values
    this.editForm = this.fb.group(
      this.fields.reduce((formControls: { [x: string]: any[]; }, field: { key: string | number; value: any; }) => {
        formControls[field.key] = [field.value]; // Initialize each control
        return formControls;
      }, {})
    );
  }

  onNotesUpdated(newNotes: string) {
    this.notes = newNotes;
  }

  onUrlUpdated(newUrl: string) {
    this.informationUrl = newUrl;
  }

  isModalOpen = false;
  public editForm!: FormGroup;



  // Define the structure of the fields array
  fields:any = [
    { label: 'Name', key: 'name', value: 'Gaurav' },
    { label: 'Version', key: 'version', value: '1.1' },
    { label: 'Publisher', key: 'publisher', value: 'S&P' },
    { label: 'Architecture', key: 'architecture', value: 'x86' },
    { label: 'Language', key: 'language', value: 'EN' },
    { label: 'Author', key: 'author', value: 'gaurav.dhyani2@spglobal.com' },
    { label: 'Description', key: 'description', value: 'This is demo' },
  ];

 

  openEditModal() {
    this.isModalOpen = true;
    const patchValues = this.fields.reduce((values: { [x: string]: any; }, field: { key: string | number; value: any; }) => {
      values[field.key] = field.value;
      return values;
    }, {});
    this.editForm.patchValue(patchValues);
  }

  closeEditModal() {
    this.isModalOpen = false;
  }

  submitForms() {
    // Update the fields array with values from the form
    this.fields = this.fields.map((field:any) => ({
      ...field,
      value: this.editForm.get(field.key)?.value || '',
    }));
    console.log(this.fields,"55555555555555555555")
    this.isModalOpen = false;
  }

  submitForm(){
    
      this.apiService.postAppDetails().subscribe({
        next: (response) => {
          console.log('API Response:', response);
        },
        error: (error) => {
          console.error('Error:', error);
        },
      });
    }
  
}
  