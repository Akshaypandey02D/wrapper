import { Component } from '@angular/core';
import { DeploymentSectionComponent } from "./deployment-section/deployment-section.component";
import { PackageDetectionSectionComponent } from "./package-detection-section/package-detection-section.component";
import { AdditionalInfoSectionComponent } from "./additional-info-section/additional-info-section.component";

@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss'],
  imports: [DeploymentSectionComponent, PackageDetectionSectionComponent, AdditionalInfoSectionComponent]
})
export class GeneralComponent {
  // Dummy dynamic data for the form
  public  applicationInfo = {
    name: '-',
    version: '-',
    publisher: '-',
    architecture: 'x86',
    language: 'EN',
    author: 'bharat.singh',
    description: '-'
  };

  public deploymentConfig = {
    suppressReboot: true,
    terminalServerMode: false,
    installationMode: 'Interactive'
  };

  public packageDetectionType = 'Registry';

  public notes: string = 'this is demo';

  informationUrl: string = '';

  onNotesUpdated(newNotes: string) {
    this.notes = newNotes;
  }

  onUrlUpdated(newUrl: string) {
    this.informationUrl = newUrl;
  }
}
