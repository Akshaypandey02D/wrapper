import { Component } from '@angular/core';

@Component({
  selector: 'app-configuration',
  imports: [],
  templateUrl: './configuration.component.html',
  styleUrl: './configuration.component.scss'
})
export class ConfigurationComponent {

}
