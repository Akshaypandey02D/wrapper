import { Component } from '@angular/core';

@Component({
  selector: 'app-main-actions',
  imports: [],
  templateUrl: './main-actions.component.html',
  styleUrl: './main-actions.component.scss'
})
export class MainActionsComponent {

}
